"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/chat.js
var chat_exports = {};
__export(chat_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(chat_exports);
var import_googleapis = require("googleapis");
var import_secret_manager = require("@google-cloud/secret-manager");
var secretClient;
function initializeSecretManagerClient() {
  try {
    if (process.env.GOOGLE_CREDENTIALS) {
      console.log("\u{1F527} Using GOOGLE_CREDENTIALS from environment");
      const credentials = JSON.parse(process.env.GOOGLE_CREDENTIALS);
      secretClient = new import_secret_manager.SecretManagerServiceClient({
        credentials,
        projectId: credentials.project_id
      });
      console.log("\u2705 Secret Manager client initialized with provided credentials");
    } else {
      console.log("\u{1F527} Using default Google credentials (local development)");
      secretClient = new import_secret_manager.SecretManagerServiceClient();
      console.log("\u2705 Secret Manager client initialized with default credentials");
    }
  } catch (error) {
    console.error("\u274C Failed to initialize Secret Manager client:", error.message);
    secretClient = new import_secret_manager.SecretManagerServiceClient();
  }
}
var secretCache = /* @__PURE__ */ new Map();
async function getSecret(secretName) {
  if (secretCache.has(secretName)) {
    return secretCache.get(secretName);
  }
  try {
    const projectId = process.env.GOOGLE_CLOUD_PROJECT_ID || "digi-dan";
    const name = `projects/${projectId}/secrets/${secretName}/versions/latest`;
    const [version] = await secretClient.accessSecretVersion({ name });
    const secretValue = version.payload.data.toString();
    secretCache.set(secretName, secretValue);
    setTimeout(() => secretCache.delete(secretName), 5 * 60 * 1e3);
    return secretValue;
  } catch (error) {
    console.error(`Error accessing secret ${secretName}:`, error);
    if (process.env.NODE_ENV === "development") {
      const envValue = process.env[secretName];
      if (envValue) {
        console.log(`Using fallback environment variable for ${secretName}`);
        return envValue;
      }
    }
    throw new Error(`Could not retrieve secret: ${secretName}`);
  }
}
async function handler(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({
        error: "Method not allowed",
        details: "This endpoint only supports POST requests",
        supportedMethods: ["POST", "OPTIONS"]
      })
    };
  }
  if (!event.body) {
    return {
      statusCode: 400,
      // 400 betyder "Bad Request"
      headers,
      body: JSON.stringify({
        error: "Request body is missing",
        details: "Chat requests must include a JSON body with message data"
      })
    };
  }
  let data;
  try {
    data = JSON.parse(event.body);
  } catch (parseError) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({
        error: "Invalid JSON format in request body",
        details: "Request body must contain valid JSON data"
      })
    };
  }
  if (!data.message || typeof data.message !== "string") {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({
        error: "Invalid message format",
        details: 'Request must include a "message" field with string content'
      })
    };
  }
  if (data.message.length > 1e4) {
    return {
      statusCode: 413,
      // Payload Too Large
      headers,
      body: JSON.stringify({
        error: "Message too long",
        details: "Messages must be less than 10,000 characters",
        maxLength: 1e4,
        receivedLength: data.message.length
      })
    };
  }
  try {
    if (!secretClient) {
      initializeSecretManagerClient();
    }
    let geminiApiKey;
    try {
      geminiApiKey = await getSecret("GEMINI_API_KEY");
      console.log("\u2705 Gemini API key loaded from Secret Manager for chat");
    } catch (secretError) {
      console.log("\u26A0\uFE0F  Gemini API key not found in Secret Manager, using environment variable");
      geminiApiKey = process.env.GEMINI_API_KEY;
    }
    if (!geminiApiKey) {
      return {
        statusCode: 503,
        // Service Unavailable
        headers,
        body: JSON.stringify({
          error: "AI service not configured",
          details: "Chat functionality requires proper API configuration"
        })
      };
    }
    const mockResponse = {
      success: true,
      message: `Du skrev: "${data.message}". AI-svar kommer snart implementeras.`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      messageLength: data.message.length,
      apiConfigured: true
    };
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(mockResponse)
    };
  } catch (error) {
    console.error("Unexpected error in chat function:", error);
    const isDevelopment = process.env.NODE_ENV === "development";
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        details: isDevelopment ? error.message : "Something went wrong processing your chat request",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
