"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/get-firebase-config.js
var get_firebase_config_exports = {};
__export(get_firebase_config_exports, {
  handler: () => handler
});
var import_secret_manager, fetchSecret, handler;
var init_get_firebase_config = __esm({
  "netlify/functions/get-firebase-config.js"() {
    "use strict";
    import_secret_manager = require("@google-cloud/secret-manager");
    fetchSecret = async (secretClient, projectId, secretName) => {
      const name = `projects/${projectId}/secrets/${secretName}/versions/latest`;
      try {
        const [version] = await secretClient.accessSecretVersion({ name });
        return version.payload.data.toString();
      } catch (error) {
        console.error(`\u274C Failed to fetch secret: ${secretName}`, error.message);
        return null;
      }
    };
    handler = async (event, context) => {
      const headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        // Ändra till din domän i produktion för ökad säkerhet
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "GET, OPTIONS"
      };
      if (event.httpMethod === "OPTIONS") {
        return {
          statusCode: 200,
          headers,
          body: ""
        };
      }
      if (event.httpMethod !== "GET") {
        return {
          statusCode: 405,
          headers,
          body: JSON.stringify({
            error: "Method not allowed",
            details: "Only GET requests are supported"
          })
        };
      }
      console.log("\u{1F527} Initializing Firebase config retrieval from Secret Manager");
      let credentials;
      if (!process.env.GOOGLE_CREDENTIALS) {
        console.error("\u274C GOOGLE_CREDENTIALS environment variable not found");
        return {
          statusCode: 500,
          headers,
          body: JSON.stringify({
            error: "Server configuration error",
            details: "Google credentials not configured"
          })
        };
      }
      try {
        credentials = JSON.parse(process.env.GOOGLE_CREDENTIALS);
        console.log("\u2705 Successfully parsed Google credentials");
      } catch (e) {
        console.error("\u274C Failed to parse GOOGLE_CREDENTIALS:", e.message);
        return {
          statusCode: 500,
          headers,
          body: JSON.stringify({
            error: "Server configuration error",
            details: "Invalid credentials format"
          })
        };
      }
      try {
        const secretClient = new import_secret_manager.SecretManagerServiceClient({
          credentials,
          projectId: credentials.project_id
        });
        const projectId = credentials.project_id;
        console.log(`\u2705 Secret Manager client initialized for project: ${projectId}`);
        const secretsToFetch = [
          "FIREBASE_API_KEY",
          "FIREBASE_AUTH_DOMAIN",
          "FIREBASE_PROJECT_ID",
          "FIREBASE_STORAGE_BUCKET",
          "FIREBASE_MESSAGING_SENDER_ID",
          "FIREBASE_APP_ID"
        ];
        console.log("\u{1F50D} Fetching Firebase secrets:", secretsToFetch);
        const secretPromises = secretsToFetch.map(
          (secretName) => fetchSecret(secretClient, projectId, secretName)
        );
        const resolvedSecrets = await Promise.all(secretPromises);
        const failedSecrets = secretsToFetch.filter((name, index) => resolvedSecrets[index] === null);
        if (failedSecrets.length > 0) {
          console.error("\u274C Failed to retrieve secrets:", failedSecrets);
          return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
              error: "Failed to retrieve all necessary Firebase secrets",
              details: `Missing secrets: ${failedSecrets.join(", ")}`,
              missingSecrets: failedSecrets
            })
          };
        }
        const firebaseConfig = {
          apiKey: resolvedSecrets[0],
          authDomain: resolvedSecrets[1],
          projectId: resolvedSecrets[2],
          storageBucket: resolvedSecrets[3],
          messagingSenderId: resolvedSecrets[4],
          appId: resolvedSecrets[5]
        };
        const missingValues = Object.entries(firebaseConfig).filter(([key, value]) => !value || value.trim() === "").map(([key]) => key);
        if (missingValues.length > 0) {
          console.error("\u274C Firebase config has empty values:", missingValues);
          return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
              error: "Incomplete Firebase configuration",
              details: `Empty values for: ${missingValues.join(", ")}`,
              emptyFields: missingValues
            })
          };
        }
        console.log("\u2705 Successfully retrieved complete Firebase configuration");
        console.log(`   - API Key length: ${firebaseConfig.apiKey.length}`);
        console.log(`   - Auth Domain: ${firebaseConfig.authDomain}`);
        console.log(`   - Project ID: ${firebaseConfig.projectId}`);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            ...firebaseConfig,
            // Lägg till metadata för debugging
            _metadata: {
              retrievedAt: (/* @__PURE__ */ new Date()).toISOString(),
              project: projectId,
              secretsRetrieved: secretsToFetch.length
            }
          })
        };
      } catch (error) {
        console.error("\u274C Unexpected error in get-firebase-config:", error);
        return {
          statusCode: 500,
          headers,
          body: JSON.stringify({
            error: "Internal server error",
            details: process.env.NODE_ENV === "development" ? error.message : "Failed to retrieve Firebase configuration",
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
    };
  }
});

// netlify/functions/test-firebase-config.js
var test_firebase_config_exports = {};
__export(test_firebase_config_exports, {
  handler: () => handler2
});
module.exports = __toCommonJS(test_firebase_config_exports);
async function handler2(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Only GET requests allowed" })
    };
  }
  try {
    console.log("\u{1F9EA} Testing Firebase configuration from get-firebase-config function");
    const { handler: getFirebaseConfigHandler } = await Promise.resolve().then(() => (init_get_firebase_config(), get_firebase_config_exports));
    const testEvent = {
      httpMethod: "GET",
      queryStringParameters: {}
    };
    const configResponse = await getFirebaseConfigHandler(testEvent, context);
    let testResults = {
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      configRetrievalTest: {
        statusCode: configResponse.statusCode,
        success: configResponse.statusCode === 200
      },
      firebaseConfigValidation: {},
      summary: {}
    };
    if (configResponse.statusCode === 200) {
      try {
        const firebaseConfig = JSON.parse(configResponse.body);
        const requiredFields = [
          "apiKey",
          "authDomain",
          "projectId",
          "storageBucket",
          "messagingSenderId",
          "appId"
        ];
        let validationResults = {};
        let validFields = 0;
        let totalFields = requiredFields.length;
        for (const field of requiredFields) {
          const value = firebaseConfig[field];
          const isValid = value && typeof value === "string" && value.trim().length > 0;
          validationResults[field] = {
            present: !!value,
            valid: isValid,
            length: value ? value.length : 0,
            preview: value ? `${value.substring(0, 10)}...` : "MISSING"
          };
          if (isValid) validFields++;
        }
        testResults.firebaseConfigValidation = {
          configStructure: validationResults,
          summary: {
            totalFields,
            validFields,
            invalidFields: totalFields - validFields,
            allFieldsValid: validFields === totalFields
          }
        };
        const formatTests = {
          apiKeyFormat: /^AIza[0-9A-Za-z_-]{35}$/.test(firebaseConfig.apiKey || ""),
          authDomainFormat: /^[a-z0-9-]+\.firebaseapp\.com$/.test(firebaseConfig.authDomain || ""),
          projectIdFormat: /^[a-z0-9-]+$/.test(firebaseConfig.projectId || ""),
          storageBucketFormat: /^[a-z0-9.-]+\.appspot\.com$/.test(firebaseConfig.storageBucket || ""),
          messagingSenderIdFormat: /^[0-9]+$/.test(firebaseConfig.messagingSenderId || ""),
          appIdFormat: /^1:[0-9]+:web:[a-f0-9]+$/.test(firebaseConfig.appId || "")
        };
        const validFormats = Object.values(formatTests).filter(Boolean).length;
        const totalFormats = Object.keys(formatTests).length;
        testResults.firebaseConfigValidation.formatValidation = {
          tests: formatTests,
          summary: {
            validFormats,
            totalFormats,
            allFormatsValid: validFormats === totalFormats
          }
        };
        testResults.summary = {
          overallSuccess: testResults.configRetrievalTest.success && testResults.firebaseConfigValidation.summary.allFieldsValid && testResults.firebaseConfigValidation.formatValidation.summary.allFormatsValid,
          configRetrievalWorking: testResults.configRetrievalTest.success,
          allSecretsPresent: testResults.firebaseConfigValidation.summary.allFieldsValid,
          allFormatsValid: testResults.firebaseConfigValidation.formatValidation.summary.allFormatsValid,
          readyForFirebaseInit: testResults.configRetrievalTest.success && testResults.firebaseConfigValidation.summary.allFieldsValid
        };
      } catch (parseError) {
        testResults.firebaseConfigValidation = {
          error: "Failed to parse Firebase config response",
          details: parseError.message
        };
      }
    } else {
      testResults.firebaseConfigValidation = {
        error: "Could not retrieve Firebase config",
        statusCode: configResponse.statusCode,
        response: JSON.parse(configResponse.body)
      };
    }
    console.log("\u{1F9EA} Firebase config test complete:", JSON.stringify(testResults, null, 2));
    const overallSuccess = testResults.summary?.overallSuccess ?? false;
    return {
      statusCode: overallSuccess ? 200 : 500,
      headers,
      body: JSON.stringify(testResults, null, 2)
    };
  } catch (error) {
    console.error("\u274C Firebase config test failed:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Firebase config test function failed",
        details: error.message,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
