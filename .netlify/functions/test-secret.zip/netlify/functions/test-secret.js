"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/get-secret.js
var get_secret_exports = {};
__export(get_secret_exports, {
  handler: () => handler
});
var import_secret_manager, handler;
var init_get_secret = __esm({
  "netlify/functions/get-secret.js"() {
    "use strict";
    import_secret_manager = require("@google-cloud/secret-manager");
    handler = async (event, context) => {
      const headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "GET, OPTIONS"
      };
      if (event.httpMethod === "OPTIONS") {
        return {
          statusCode: 200,
          headers,
          body: ""
        };
      }
      if (event.httpMethod !== "GET") {
        return {
          statusCode: 405,
          headers,
          body: JSON.stringify({
            error: "Method not allowed",
            details: "Only GET requests are supported"
          })
        };
      }
      try {
        let credentials;
        if (process.env.GOOGLE_CREDENTIALS) {
          console.log("\u{1F527} Using GOOGLE_CREDENTIALS from Netlify environment");
          try {
            credentials = JSON.parse(process.env.GOOGLE_CREDENTIALS);
            console.log("\u2705 Successfully parsed Google credentials");
          } catch (parseError) {
            console.error("\u274C Failed to parse GOOGLE_CREDENTIALS:", parseError.message);
            return {
              statusCode: 503,
              headers,
              body: JSON.stringify({
                error: "Invalid credentials configuration",
                details: "GOOGLE_CREDENTIALS environment variable contains invalid JSON"
              })
            };
          }
        } else {
          console.error("\u274C GOOGLE_CREDENTIALS environment variable not found");
          return {
            statusCode: 503,
            headers,
            body: JSON.stringify({
              error: "Credentials not configured",
              details: "GOOGLE_CREDENTIALS environment variable is required"
            })
          };
        }
        const secretClient = new import_secret_manager.SecretManagerServiceClient({
          credentials,
          projectId: credentials.project_id
        });
        console.log(`\u2705 Secret Manager client initialized for project: ${credentials.project_id}`);
        const { secret } = event.queryStringParameters || {};
        if (!secret) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({
              error: "Secret name required",
              details: "Provide secret name as query parameter: ?secret=SECRET_NAME",
              examples: [
                "GEMINI_API_KEY",
                "GOOGLE_CLIENT_ID",
                "GOOGLE_CLIENT_SECRET"
              ]
            })
          };
        }
        if (!/^[A-Z_][A-Z0-9_]*$/.test(secret)) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({
              error: "Invalid secret name format",
              details: "Secret names must contain only uppercase letters, numbers, and underscores"
            })
          };
        }
        console.log(`\u{1F50D} Attempting to retrieve secret: ${secret}`);
        const projectId = credentials.project_id;
        const name = `projects/${projectId}/secrets/${secret}/versions/latest`;
        const [version] = await secretClient.accessSecretVersion({ name });
        const secretValue = version.payload.data.toString();
        console.log(`\u2705 Successfully retrieved secret: ${secret} (length: ${secretValue.length})`);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            success: true,
            secretName: secret,
            value: secretValue,
            project: projectId,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      } catch (error) {
        console.error("\u274C Error in get-secret function:", error);
        if (error.code === 5) {
          return {
            statusCode: 404,
            headers,
            body: JSON.stringify({
              error: "Secret not found",
              details: `The requested secret does not exist in Google Secret Manager`
            })
          };
        }
        if (error.code === 7) {
          return {
            statusCode: 403,
            headers,
            body: JSON.stringify({
              error: "Access denied",
              details: "The service account does not have permission to access this secret"
            })
          };
        }
        if (error.message.includes("ENOTFOUND") || error.message.includes("network")) {
          return {
            statusCode: 503,
            headers,
            body: JSON.stringify({
              error: "Network error",
              details: "Unable to connect to Google Secret Manager"
            })
          };
        }
        return {
          statusCode: 500,
          headers,
          body: JSON.stringify({
            error: "Internal server error",
            details: process.env.NODE_ENV === "development" ? error.message : "Failed to retrieve secret",
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
    };
  }
});

// netlify/functions/test-secret.js
var test_secret_exports = {};
__export(test_secret_exports, {
  handler: () => handler2
});
module.exports = __toCommonJS(test_secret_exports);
async function handler2(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Only GET requests allowed" })
    };
  }
  try {
    console.log("\u{1F9EA} Testing get-secret functionality");
    const hasCredentials = !!process.env.GOOGLE_CREDENTIALS;
    console.log(`Environment check - GOOGLE_CREDENTIALS exists: ${hasCredentials}`);
    let credentialsParsed = false;
    let projectId = null;
    if (hasCredentials) {
      try {
        const creds = JSON.parse(process.env.GOOGLE_CREDENTIALS);
        credentialsParsed = true;
        projectId = creds.project_id;
        console.log(`\u2705 Credentials parsed successfully, project: ${projectId}`);
      } catch (e) {
        console.error("\u274C Failed to parse GOOGLE_CREDENTIALS");
      }
    }
    let secretTestResult = null;
    try {
      const { handler: getSecretHandler } = await Promise.resolve().then(() => (init_get_secret(), get_secret_exports));
      const testEvent = {
        httpMethod: "GET",
        queryStringParameters: { secret: "GEMINI_API_KEY" }
      };
      const result = await getSecretHandler(testEvent, context);
      secretTestResult = {
        statusCode: result.statusCode,
        success: result.statusCode === 200,
        hasValue: result.statusCode === 200 && JSON.parse(result.body).value?.length > 0
      };
      console.log(`Secret test result: ${JSON.stringify(secretTestResult)}`);
    } catch (error) {
      console.error("Secret test failed:", error.message);
      secretTestResult = { error: error.message };
    }
    const commonSecrets = ["GEMINI_API_KEY", "GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET"];
    const secretTests = [];
    for (const secretName of commonSecrets) {
      try {
        const { handler: getSecretHandler } = await Promise.resolve().then(() => (init_get_secret(), get_secret_exports));
        const testEvent = {
          httpMethod: "GET",
          queryStringParameters: { secret: secretName }
        };
        const result = await getSecretHandler(testEvent, context);
        secretTests.push({
          name: secretName,
          statusCode: result.statusCode,
          available: result.statusCode === 200,
          hasValue: result.statusCode === 200 ? JSON.parse(result.body).value?.length > 0 : false
        });
      } catch (error) {
        secretTests.push({
          name: secretName,
          available: false,
          error: error.message
        });
      }
    }
    const testResults = {
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      environment: {
        hasGoogleCredentials: hasCredentials,
        credentialsParsedSuccessfully: credentialsParsed,
        projectId
      },
      secretManagerTest: secretTestResult,
      commonSecrets: secretTests,
      summary: {
        totalSecretsChecked: commonSecrets.length,
        availableSecrets: secretTests.filter((s) => s.available).length,
        unavailableSecrets: secretTests.filter((s) => !s.available).length
      }
    };
    console.log("\u{1F9EA} Test complete:", JSON.stringify(testResults, null, 2));
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(testResults, null, 2)
    };
  } catch (error) {
    console.error("\u274C Test function error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Test function failed",
        details: error.message,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
