
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/purge-cache.js
import { purgeCache } from "@netlify/functions";
var purge_cache_default = async (req, context) => {
  try {
    console.log("\u{1F9F9} Purging Netlify CDN cache...");
    await purgeCache({
      tags: ["all"],
      // Använd en bred tagg för att rensa allt
      site_slug: context.site?.name || "byggpilot"
    });
    console.log("\u2705 Cache purged successfully!");
    return new Response(JSON.stringify({
      success: true,
      message: "CDN cache has been purged! Old Firebase files should be cleared.",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }), {
      status: 202,
      headers: {
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("\u274C Cache purge failed:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
};
export {
  purge_cache_default as default
};
