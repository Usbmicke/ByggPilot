"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/auth.js
var auth_exports = {};
__export(auth_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(auth_exports);
var import_googleapis = require("googleapis");
var import_secret_manager = require("@google-cloud/secret-manager");
var secretClient;
var oauth2Client;
function initializeSecretManagerClient() {
  try {
    if (process.env.GOOGLE_CREDENTIALS) {
      console.log("\u{1F527} Using GOOGLE_CREDENTIALS from environment");
      const credentials = JSON.parse(process.env.GOOGLE_CREDENTIALS);
      secretClient = new import_secret_manager.SecretManagerServiceClient({
        credentials,
        projectId: credentials.project_id
      });
      console.log("\u2705 Secret Manager client initialized with provided credentials");
    } else {
      console.log("\u{1F527} Using default Google credentials (local development)");
      secretClient = new import_secret_manager.SecretManagerServiceClient();
      console.log("\u2705 Secret Manager client initialized with default credentials");
    }
  } catch (error) {
    console.error("\u274C Failed to initialize Secret Manager client:", error.message);
    secretClient = new import_secret_manager.SecretManagerServiceClient();
  }
}
var secretCache = /* @__PURE__ */ new Map();
async function getSecret(secretName) {
  if (secretCache.has(secretName)) {
    return secretCache.get(secretName);
  }
  try {
    const projectId = process.env.GOOGLE_CLOUD_PROJECT_ID || "digi-dan";
    const name = `projects/${projectId}/secrets/${secretName}/versions/latest`;
    const [version] = await secretClient.accessSecretVersion({ name });
    const secretValue = version.payload.data.toString();
    secretCache.set(secretName, secretValue);
    setTimeout(() => secretCache.delete(secretName), 5 * 60 * 1e3);
    return secretValue;
  } catch (error) {
    console.error(`Error accessing secret ${secretName}:`, error);
    if (process.env.NODE_ENV === "development") {
      const envValue = process.env[secretName];
      if (envValue) {
        console.log(`Using fallback environment variable for ${secretName}`);
        return envValue;
      }
    }
    throw new Error(`Could not retrieve secret: ${secretName}`);
  }
}
async function initializeOAuth() {
  try {
    let clientId, clientSecret, redirectUri;
    try {
      clientId = await getSecret("GOOGLE_CLIENT_ID");
      clientSecret = await getSecret("GOOGLE_CLIENT_SECRET");
      redirectUri = await getSecret("GOOGLE_REDIRECT_URI");
      console.log("\u2705 OAuth credentials loaded from Secret Manager");
    } catch (secretError) {
      console.log("\u{1F504} Using environment variables for OAuth");
      clientId = process.env.GOOGLE_CLIENT_ID;
      clientSecret = process.env.GOOGLE_CLIENT_SECRET;
      redirectUri = process.env.GOOGLE_REDIRECT_URI || "https://your-netlify-site.netlify.app/.netlify/functions/auth-callback";
      if (!clientId || !clientSecret) {
        console.log("\u26A0\uFE0F  OAuth credentials not found");
        return null;
      }
    }
    oauth2Client = new import_googleapis.google.auth.OAuth2(clientId, clientSecret, redirectUri);
    console.log("\u2705 OAuth2 client initialized successfully");
    return oauth2Client;
  } catch (error) {
    console.error("\u274C Failed to initialize OAuth2 client:", error.message);
    return null;
  }
}
var SCOPES = [
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
  "https://www.googleapis.com/auth/drive.file",
  "https://www.googleapis.com/auth/gmail.send",
  "https://www.googleapis.com/auth/gmail.metadata"
];
async function handler(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  try {
    if (!secretClient) {
      initializeSecretManagerClient();
    }
    if (!oauth2Client) {
      oauth2Client = await initializeOAuth();
    }
    if (!oauth2Client) {
      return {
        statusCode: 503,
        headers,
        body: JSON.stringify({
          error: "OAuth not configured",
          details: "Google OAuth credentials not available in Secret Manager or environment variables"
        })
      };
    }
    if (event.httpMethod === "GET") {
      try {
        const authUrl = oauth2Client.generateAuthUrl({
          access_type: "offline",
          scope: SCOPES,
          prompt: "consent"
        });
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            authUrl,
            scopes: SCOPES.length,
            configured: true
          })
        };
      } catch (authError) {
        console.error("Error generating auth URL:", authError);
        return {
          statusCode: 500,
          headers,
          body: JSON.stringify({
            error: "Failed to generate authorization URL",
            details: process.env.NODE_ENV === "development" ? authError.message : "OAuth configuration error"
          })
        };
      }
    }
    if (event.httpMethod === "POST") {
      if (!event.body) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            error: "Request body is missing",
            details: "POST requests must include a JSON body with authorization code"
          })
        };
      }
      let data;
      try {
        data = JSON.parse(event.body);
      } catch (parseError) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            error: "Invalid JSON format in request body",
            details: "Request body must be valid JSON"
          })
        };
      }
      if (!data.code) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            error: "Authorization code missing",
            details: 'Request must include "code" field with authorization code from Google'
          })
        };
      }
      try {
        const { tokens } = await oauth2Client.getToken(data.code);
        oauth2Client.setCredentials(tokens);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            success: true,
            hasAccessToken: !!tokens.access_token,
            hasRefreshToken: !!tokens.refresh_token
          })
        };
      } catch (tokenError) {
        console.error("Error exchanging code for tokens:", tokenError);
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            error: "Invalid authorization code",
            details: process.env.NODE_ENV === "development" ? tokenError.message : "Failed to exchange authorization code"
          })
        };
      }
    }
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({
        error: "Method not allowed",
        details: `${event.httpMethod} method is not supported. Use GET or POST.`
      })
    };
  } catch (error) {
    console.error("Unexpected error in auth function:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        details: process.env.NODE_ENV === "development" ? error.message : "Something went wrong"
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
