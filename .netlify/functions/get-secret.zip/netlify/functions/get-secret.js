"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/get-secret.js
var get_secret_exports = {};
__export(get_secret_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(get_secret_exports);
var import_secret_manager = require("@google-cloud/secret-manager");
var handler = async (event, context) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({
        error: "Method not allowed",
        details: "Only GET requests are supported"
      })
    };
  }
  try {
    let credentials;
    if (process.env.GOOGLE_CREDENTIALS) {
      console.log("\u{1F527} Using GOOGLE_CREDENTIALS from Netlify environment");
      try {
        credentials = JSON.parse(process.env.GOOGLE_CREDENTIALS);
        console.log("\u2705 Successfully parsed Google credentials");
      } catch (parseError) {
        console.error("\u274C Failed to parse GOOGLE_CREDENTIALS:", parseError.message);
        return {
          statusCode: 503,
          headers,
          body: JSON.stringify({
            error: "Invalid credentials configuration",
            details: "GOOGLE_CREDENTIALS environment variable contains invalid JSON"
          })
        };
      }
    } else {
      console.error("\u274C GOOGLE_CREDENTIALS environment variable not found");
      return {
        statusCode: 503,
        headers,
        body: JSON.stringify({
          error: "Credentials not configured",
          details: "GOOGLE_CREDENTIALS environment variable is required"
        })
      };
    }
    const secretClient = new import_secret_manager.SecretManagerServiceClient({
      credentials,
      projectId: credentials.project_id
    });
    console.log(`\u2705 Secret Manager client initialized for project: ${credentials.project_id}`);
    const { secret } = event.queryStringParameters || {};
    if (!secret) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Secret name required",
          details: "Provide secret name as query parameter: ?secret=SECRET_NAME",
          examples: [
            "GEMINI_API_KEY",
            "GOOGLE_CLIENT_ID",
            "GOOGLE_CLIENT_SECRET"
          ]
        })
      };
    }
    if (!/^[A-Z_][A-Z0-9_]*$/.test(secret)) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Invalid secret name format",
          details: "Secret names must contain only uppercase letters, numbers, and underscores"
        })
      };
    }
    console.log(`\u{1F50D} Attempting to retrieve secret: ${secret}`);
    const projectId = credentials.project_id;
    const name = `projects/${projectId}/secrets/${secret}/versions/latest`;
    const [version] = await secretClient.accessSecretVersion({ name });
    const secretValue = version.payload.data.toString();
    console.log(`\u2705 Successfully retrieved secret: ${secret} (length: ${secretValue.length})`);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        secretName: secret,
        value: secretValue,
        project: projectId,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  } catch (error) {
    console.error("\u274C Error in get-secret function:", error);
    if (error.code === 5) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({
          error: "Secret not found",
          details: `The requested secret does not exist in Google Secret Manager`
        })
      };
    }
    if (error.code === 7) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({
          error: "Access denied",
          details: "The service account does not have permission to access this secret"
        })
      };
    }
    if (error.message.includes("ENOTFOUND") || error.message.includes("network")) {
      return {
        statusCode: 503,
        headers,
        body: JSON.stringify({
          error: "Network error",
          details: "Unable to connect to Google Secret Manager"
        })
      };
    }
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        details: process.env.NODE_ENV === "development" ? error.message : "Failed to retrieve secret",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
